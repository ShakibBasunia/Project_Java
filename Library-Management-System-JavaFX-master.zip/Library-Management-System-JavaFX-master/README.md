# Library Management System

## This Project Running on

- JavaFX
- JDK Version : 10
- Oracle 11g Express Edition

![Splash Screen](screenshots/SplashScreen.PNG)
![Login Form](screenshots/loginscreen.PNG)
![Dashboard Form](screenshots/dashboard.PNG)
![Student Form](screenshots/student.PNG)
![Book Form](screenshots/book.PNG)
![Issue Book Form](screenshots/Issue.PNG)
![Return Book Form](screenshots/return.PNG)
![Setting](screenshots/setting.PNG)