package com.ghulam.dashboard;

import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;

public interface Reportable {
    void setPane(StackPane stackPane, AnchorPane rootPane);
}
