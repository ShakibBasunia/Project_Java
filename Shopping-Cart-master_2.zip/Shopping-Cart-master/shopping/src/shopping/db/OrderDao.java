package shopping.db;

public class OrderDao {

}
